/* ====================================================================
 * lora.c  —  TRANSMITTER LoRa driver (state-machine version)
 *
 * KEY BEHAVIOURS:
 *
 * 1. Powers up in DISCONNECTED.  Sends @HI every TX_HELLO_RETRY_MS.
 *    Will NOT transmit @TL data until handshake is confirmed.
 *
 * 2. HELLO retry timing (fixed):
 *      • First HELLO fires 3 s after boot (s_lastHelloTick = 0 at init)
 *      • If handshake FAILS: retries in 1 s (not 3 s dead zone)
 *      • If handshake OK:    sends @TL IMMEDIATELY (no 10 s hold)
 *      • Subsequent @TL:     every TX_DATA_INTERVAL_MS (10 s)
 *
 * 3. Connection maintenance:
 *      • PING every TX_KEEPALIVE_INTERVAL_MS (30 s) when idle
 *      • TX_NOACK_DISCONNECT_THRESH (3) consecutive @TL failures → DC
 *
 * 4. LIVE EXPRESSIONS (add in STM32CubeIDE):
 *      g_lastTxPacket   — last packet sent OTA (@HI / @TL / @PI)
 *      g_txConnected    — 0=disconnected, 1=connected
 *      g_lora_tx_ok     — cumulative ACK'd TX count
 *      g_lora_tx_fail   — cumulative failed TX count
 *      s_helloAttempts  — how many HELLOs sent since boot
 * ==================================================================== */

#include "lora.h"
#include "lora_parser.h"
#include "device_id.h"
#include "stm32f1xx_hal.h"
#include <string.h>
#include <stdio.h>
#include <stdbool.h>

extern SPI_HandleTypeDef  hspi1;
extern UART_HandleTypeDef huart1;
extern void UART_PrintLn(const char *s);

/* txPacket is defined in main.c — extern reference only.             */
extern volatile char txPacket[TX_PACKET_SIZE];

/* ── Debug buffer for Live Expressions ─────────────────────────────── */
volatile char g_lastTxPacket[MAX_PACKET_LEN] = {0};

/* ── Public globals ─────────────────────────────────────────────────── */
uint8_t  loraMode        = LORA_MODE_TRANSMITTER;
uint8_t  g_txConnected   = 0;
uint8_t  g_txDebugMode   = 0;
uint32_t g_lora_tx_ok    = 0;
uint32_t g_lora_tx_retry = 0;
uint32_t g_lora_tx_fail  = 0;

/* ── Private state ──────────────────────────────────────────────────── */
static LoRa_ConnState_t s_state            = LORA_STATE_DISCONNECTED;
static uint32_t         s_txSeq            = 0;
static uint32_t         s_lastDataTxTick   = 0;
static uint32_t         s_lastAnyTxTick    = 0;
static uint32_t         s_lastHelloTick    = 0;
static uint8_t          s_consecCycleFails = 0;
static uint8_t          s_rxBuf[LORA_BUF_SIZE];

/* Triggers immediate @TL send on the first CONNECTED service call.    */
static bool             s_justConnected    = false;

/* Diagnostic counter — visible in debugger                            */
static uint32_t         s_helloAttempts    = 0;

#define NSS_LOW()   HAL_GPIO_WritePin(LORA_NSS_PORT, LORA_NSS_PIN, GPIO_PIN_RESET)
#define NSS_HIGH()  HAL_GPIO_WritePin(LORA_NSS_PORT, LORA_NSS_PIN, GPIO_PIN_SET)

/* ── Retry timing helper ────────────────────────────────────────────── *
 * After a failed handshake we want to retry in FAST_RETRY_MS (1 s)
 * rather than the full TX_HELLO_RETRY_INTERVAL_MS (3 s).  We achieve
 * this by winding s_lastHelloTick back so the guard expires sooner.
 * ──────────────────────────────────────────────────────────────────── */
#define FAST_RETRY_MS   1000UL

static void schedule_fast_retry(void)
{
    /* Make (now - s_lastHelloTick) reach TX_HELLO_RETRY_INTERVAL_MS
     * in FAST_RETRY_MS from now.                                      */
    s_lastHelloTick = HAL_GetTick()
                      - (TX_HELLO_RETRY_INTERVAL_MS - FAST_RETRY_MS);
}

/* ── SPI primitives ─────────────────────────────────────────────────── */

void LoRa_WriteReg(uint8_t addr, uint8_t data)
{
    uint8_t buf[2] = { (uint8_t)(addr | 0x80u), data };
    NSS_LOW();
    HAL_SPI_Transmit(&hspi1, buf, 2, HAL_MAX_DELAY);
    NSS_HIGH();
}

uint8_t LoRa_ReadReg(uint8_t addr)
{
    uint8_t tx = (uint8_t)(addr & 0x7Fu), rx = 0;
    NSS_LOW();
    HAL_SPI_Transmit(&hspi1, &tx, 1, HAL_MAX_DELAY);
    HAL_SPI_Receive(&hspi1, &rx, 1, HAL_MAX_DELAY);
    NSS_HIGH();
    return rx;
}

static void LoRa_WriteBuffer(uint8_t addr, const uint8_t *data, uint8_t size)
{
    uint8_t a = (uint8_t)(addr | 0x80u);
    NSS_LOW();
    HAL_SPI_Transmit(&hspi1, &a, 1, HAL_MAX_DELAY);
    HAL_SPI_Transmit(&hspi1, (uint8_t *)data, size, HAL_MAX_DELAY);
    NSS_HIGH();
}

static void LoRa_ReadBuffer(uint8_t addr, uint8_t *data, uint8_t size)
{
    uint8_t a = (uint8_t)(addr & 0x7Fu);
    NSS_LOW();
    HAL_SPI_Transmit(&hspi1, &a, 1, HAL_MAX_DELAY);
    HAL_SPI_Receive(&hspi1, data, size, HAL_MAX_DELAY);
    NSS_HIGH();
}

/* ── Radio helpers ──────────────────────────────────────────────────── */

static void LoRa_Reset(void)
{
    HAL_GPIO_WritePin(LORA_RESET_PORT, LORA_RESET_PIN, GPIO_PIN_RESET);
    HAL_Delay(5);
    HAL_GPIO_WritePin(LORA_RESET_PORT, LORA_RESET_PIN, GPIO_PIN_SET);
    HAL_Delay(10);
}

static inline void LoRa_Standby(void)  { LoRa_WriteReg(0x01, 0x81u); }
static inline void LoRa_RxSingle(void)
{
    LoRa_WriteReg(0x12, 0xFFu);  /* clear IRQs */
    LoRa_WriteReg(0x01, 0x86u);  /* RX Single  */
}

/* ── Low-level TX (one packet, no retry) ───────────────────────────── */
static bool LoRa_DoTransmit(const char *pkt, uint8_t len)
{
    if (pkt == NULL || len == 0u || len >= LORA_BUF_SIZE) return false;

    /* Update debug buffer so Live Expressions shows last OTA packet   */
    if (len < MAX_PACKET_LEN)
    {
        memcpy((void *)g_lastTxPacket, pkt, len);
        g_lastTxPacket[len] = '\0';
    }

    LoRa_Standby();
    HAL_Delay(LORA_TX_TO_RX_GAP_MS);

    LoRa_WriteReg(0x0D, 0x00u);                        /* FifoAddrPtr=0 */
    LoRa_WriteBuffer(0x00u, (const uint8_t *)pkt, len);
    LoRa_WriteReg(0x22u, len);                         /* PayloadLen    */
    LoRa_WriteReg(0x12u, 0xFFu);                       /* clear IRQs    */
    LoRa_WriteReg(0x01u, 0x83u);                       /* TX mode       */

    uint32_t t0 = HAL_GetTick();
    while ((LoRa_ReadReg(0x12u) & 0x08u) == 0u)
    {
        if ((HAL_GetTick() - t0) > LORA_TX_TIMEOUT_MS)
        {
            LoRa_WriteReg(0x12u, 0xFFu);
            LoRa_Standby();
            UART_PrintLn("[LORA TX] !!! TX timeout — radio issue?");
            return false;
        }
    }

    LoRa_WriteReg(0x12u, 0x08u);  /* clear TxDone */
    LoRa_Standby();
    s_lastAnyTxTick = HAL_GetTick();
    return true;
}

/* ── Low-level RX, single shot with timeout ────────────────────────── */
static uint8_t LoRa_DoReceive(uint32_t timeout_ms)
{
    HAL_Delay(LORA_RX_TO_TX_GAP_MS);
    LoRa_RxSingle();

    uint32_t t0 = HAL_GetTick();
    while ((HAL_GetTick() - t0) < timeout_ms)
    {
        if (HAL_GPIO_ReadPin(LORA_DIO0_PORT, LORA_DIO0_PIN) == GPIO_PIN_RESET)
            continue;

        uint8_t irq = LoRa_ReadReg(0x12u);
        LoRa_WriteReg(0x12u, 0xFFu);

        if (irq & 0x20u) { LoRa_Standby(); return 0; }   /* CRC err  */
        if ((irq & 0x40u) == 0u) continue;                /* not Done */

        uint8_t len = LoRa_ReadReg(0x13u);
        if (len == 0u || len >= (LORA_BUF_SIZE - 1u))
        {
            LoRa_Standby();
            return 0;
        }

        LoRa_WriteReg(0x0Du, LoRa_ReadReg(0x10u));
        LoRa_ReadBuffer(0x00u, s_rxBuf, len);
        s_rxBuf[len] = '\0';
        LoRa_Standby();
        return len;
    }

    LoRa_WriteReg(0x12u, 0xFFu);
    LoRa_Standby();
    return 0;
}

/* ── State helper ───────────────────────────────────────────────────── */
static void set_state(LoRa_ConnState_t new_state)
{
    if (s_state == new_state) return;
    s_state = new_state;
    g_txConnected = (new_state == LORA_STATE_CONNECTED) ? 1u : 0u;

    char dbg[64];
    snprintf(dbg, sizeof(dbg),
             "[LORA TX] STATE -> %s  (connected=%u)",
             LoRa_GetStateString(), (unsigned)g_txConnected);
    UART_PrintLn(dbg);
}

const char *LoRa_GetStateString(void)
{
    switch (s_state)
    {
        case LORA_STATE_DISCONNECTED: return "DISCONNECTED";
        case LORA_STATE_HANDSHAKING : return "HANDSHAKING";
        case LORA_STATE_CONNECTED   : return "CONNECTED";
        case LORA_STATE_STALE       : return "STALE";
        default                     : return "?";
    }
}

LoRa_ConnState_t LoRa_GetState    (void) { return s_state;  }
uint32_t         LoRa_GetTxSequence(void){ return s_txSeq;  }

/* ── TX + wait for response ─────────────────────────────────────────── */
static bool send_and_wait_response(const char *pkt, uint8_t len,
                                   uint32_t wait_ms,
                                   ParsedPacket_t *out_resp)
{
    if (!LoRa_DoTransmit(pkt, len)) return false;
    uint8_t rlen = LoRa_DoReceive(wait_ms);
    if (rlen == 0) return false;
    return LoRa_ParsePacket((const char *)s_rxBuf, out_resp);
}

/* ── One handshake attempt ──────────────────────────────────────────── */
static bool do_handshake_once(void)
{
    char hello[32];
    int  n = LoRa_BuildHello(hello, sizeof(hello), DeviceID_GetOwn());
    if (n <= 0) return false;

    s_helloAttempts++;
    char dbg[80];
    snprintf(dbg, sizeof(dbg),
             "[LORA TX] >> HELLO attempt #%lu (DID %s)",
             (unsigned long)s_helloAttempts, hello + 4);  /* skip @HI: */
    UART_PrintLn(dbg);

    ParsedPacket_t resp;
    bool got = send_and_wait_response(hello, (uint8_t)n,
                                      LORA_HELLO_ACK_WAIT_MS, &resp);

    if (!got)
    {
        UART_PrintLn("[LORA TX] << no ACK received within window");
        return false;
    }

    snprintf(dbg, sizeof(dbg),
             "[LORA TX] << response type=%d  DID=%08lX",
             (int)resp.type, (unsigned long)resp.did);
    UART_PrintLn(dbg);

    if (resp.type == PKT_TYPE_ACK && resp.did == DeviceID_GetOwn())
        return true;

    if (resp.type == PKT_TYPE_REJECT)
        UART_PrintLn("[LORA TX] HELLO rejected — RX not in pairing mode?");

    return false;
}

/* ── On-demand handshake trigger (e.g. button) ──────────────────────── */
bool LoRa_TriggerHandshake(void)
{
    UART_PrintLn("[LORA TX] Manual HELLO requested");
    set_state(LORA_STATE_HANDSHAKING);
    s_lastHelloTick = HAL_GetTick();

    if (do_handshake_once())
    {
        UART_PrintLn("[LORA TX] *** MANUAL HANDSHAKE OK — CONNECTED ***");
        s_lastDataTxTick = 0;        /* trigger immediate @TL           */
        s_lastAnyTxTick  = HAL_GetTick();
        s_justConnected  = true;
        set_state(LORA_STATE_CONNECTED);
        s_consecCycleFails = 0;
        return true;
    }

    UART_PrintLn("[LORA TX] Manual HELLO failed");
    set_state(LORA_STATE_DISCONNECTED);
    schedule_fast_retry();
    return false;
}

void LoRa_ManualHello(void) { (void)LoRa_TriggerHandshake(); }

/* ── Graceful disconnect ────────────────────────────────────────────── */
void LoRa_SendBye(void)
{
    char bye[24];
    int  n = LoRa_BuildBye(bye, sizeof(bye), DeviceID_GetOwn());
    if (n > 0) (void)LoRa_DoTransmit(bye, (uint8_t)n);
}

/* ── Compat shim for older adc.c callers ───────────────────────────── */
void LoRa_BuildDataPacket(char *out, uint16_t out_size,
                          uint8_t tank_level, uint8_t well_dry)
{
    (void)LoRa_BuildData(out, (int)out_size,
                         DeviceID_GetOwn(), s_txSeq,
                         tank_level, well_dry);
}

/* ── DATA TX with retries ───────────────────────────────────────────── */
static LoRa_TxResult send_data_with_retries(uint8_t level, uint8_t wd)
{
    uint32_t seq = s_txSeq + 1u;

    for (uint8_t attempt = 0u; attempt < TX_DATA_RETRY_MAX; attempt++)
    {
        char pkt[MAX_PACKET_LEN];
        int  n = LoRa_BuildData(pkt, sizeof(pkt),
                                DeviceID_GetOwn(), seq, level, wd);
        if (n <= 0) { g_lora_tx_fail++; return LORA_TX_FAIL; }

        char dbg[120];
        snprintf(dbg, sizeof(dbg),
                 "[LORA TX] @TL attempt %u/%u  lvl=%u%%  wd=%u  seq=%08lX",
                 (unsigned)(attempt + 1u), (unsigned)TX_DATA_RETRY_MAX,
                 (unsigned)level, (unsigned)wd, (unsigned long)seq);
        UART_PrintLn(dbg);

        ParsedPacket_t resp;
        bool got = send_and_wait_response(pkt, (uint8_t)n,
                                          LORA_ACK_WAIT_MS, &resp);

        if (got && resp.type == PKT_TYPE_ACK && resp.did == DeviceID_GetOwn())
        {
            g_lora_tx_ok++;
            s_txSeq          = seq;
            s_lastDataTxTick = HAL_GetTick();
            UART_PrintLn("[LORA TX] @TL ACK received — OK");
            return LORA_TX_OK;
        }

        if (got && resp.type == PKT_TYPE_REJECT)
        {
            UART_PrintLn("[LORA TX] @TL rejected by RX — force re-handshake");
            g_lora_tx_fail++;
            return LORA_TX_FAIL;
        }

        if (got && resp.type == PKT_TYPE_SYNC_REQ)
        {
            UART_PrintLn("[LORA TX] RX sent SYNC_REQ — will re-handshake");
            g_lora_tx_retry++;
            return LORA_TX_FAIL;
        }

        UART_PrintLn("[LORA TX] @TL no ACK — retry");
        g_lora_tx_retry++;
    }

    g_lora_tx_fail++;
    return LORA_TX_RETRY;
}

/* ── PING / keep-alive ──────────────────────────────────────────────── */
static bool send_ping(void)
{
    char pkt[MAX_PACKET_LEN];
    int  n = LoRa_BuildPing(pkt, sizeof(pkt), DeviceID_GetOwn(), s_txSeq);
    if (n <= 0) return false;

    UART_PrintLn("[LORA TX] >> PING keep-alive");

    ParsedPacket_t resp;
    if (!send_and_wait_response(pkt, (uint8_t)n, LORA_ACK_WAIT_MS, &resp))
    {
        UART_PrintLn("[LORA TX] PING no response");
        return false;
    }

    if ((resp.type == PKT_TYPE_PONG || resp.type == PKT_TYPE_ACK)
        && resp.did == DeviceID_GetOwn())
    {
        UART_PrintLn("[LORA TX] << PONG received");
        return true;
    }
    return false;
}

/* ── Init ───────────────────────────────────────────────────────────── */
void LoRa_Init(void)
{
    DeviceID_Init();
    LoRa_Reset();

    LoRa_WriteReg(0x01u, 0x80u);    /* sleep + LoRa mode */
    HAL_Delay(10);

    /* 433 MHz */
    uint64_t frf = ((uint64_t)433000000ULL << 19) / 32000000ULL;
    LoRa_WriteReg(0x06u, (uint8_t)(frf >> 16));
    LoRa_WriteReg(0x07u, (uint8_t)(frf >>  8));
    LoRa_WriteReg(0x08u, (uint8_t)(frf));

    LoRa_WriteReg(0x20u, LORA_PREAMBLE_MSB);
    LoRa_WriteReg(0x21u, LORA_PREAMBLE_LSB);
    LoRa_WriteReg(0x09u, LORA_REG_PA_CONFIG);
    LoRa_WriteReg(0x0Bu, LORA_REG_OCP);
    LoRa_WriteReg(0x4Du, LORA_REG_PA_DAC);
    LoRa_WriteReg(0x1Du, LORA_REG_MODEM_CFG1);
    LoRa_WriteReg(0x1Eu, LORA_REG_MODEM_CFG2);
    LoRa_WriteReg(0x26u, LORA_REG_DETECT_OPT);
    LoRa_WriteReg(0x39u, LORA_SYNC_WORD);

    LoRa_Standby();

    s_state            = LORA_STATE_DISCONNECTED;
    g_txConnected      = 0;
    s_txSeq            = 0;
    s_lastDataTxTick   = 0;
    s_lastAnyTxTick    = 0;
    s_lastHelloTick    = 0;           /* fires first HELLO at 3 s       */
    s_consecCycleFails = 0;
    s_justConnected    = false;
    s_helloAttempts    = 0;

    UART_PrintLn("[LORA TX] Init done — long-range config active");
    UART_PrintLn("[LORA TX] First HELLO in 3 s...");
}

/* ====================================================================
 * LoRa_Service  —  call once per 200 ms main-loop tick
 *
 * Returns LORA_TX_SKIPPED on most calls (nothing to do yet).
 * Only returns OK/RETRY/FAIL when an actual radio exchange happened.
 * ==================================================================== */
LoRa_TxResult LoRa_Service(uint8_t tank_level, uint8_t well_dry)
{
    if (loraMode != LORA_MODE_TRANSMITTER) return LORA_TX_FAIL;

    uint32_t now = HAL_GetTick();

    /* ── DISCONNECTED ────────────────────────────────────────────────── *
     * Pace HELLO retries.  After a failed handshake we used
     * schedule_fast_retry() so the guard expires in 1 s, not 3 s.
     * ──────────────────────────────────────────────────────────────────*/
    if (s_state == LORA_STATE_DISCONNECTED)
    {
        uint32_t elapsed = now - s_lastHelloTick;

        if (elapsed < TX_HELLO_RETRY_INTERVAL_MS)
        {
            /* Show countdown every 5 calls (every ~1 s) so user can
             * see the TX is alive and just waiting.                    */
            static uint8_t skip_log = 0;
            if (++skip_log >= 5u)
            {
                skip_log = 0;
                char dbg[80];
                snprintf(dbg, sizeof(dbg),
                         "[LORA TX] DISCONNECTED — next HELLO in %lu ms",
                         (unsigned long)(TX_HELLO_RETRY_INTERVAL_MS - elapsed));
                UART_PrintLn(dbg);
            }
            return LORA_TX_SKIPPED;
        }

        /* Time to try */
        s_lastHelloTick = now;
        set_state(LORA_STATE_HANDSHAKING);

        if (do_handshake_once())
        {
            UART_PrintLn("[LORA TX] *** HANDSHAKE OK — CONNECTED ***");
            /* s_lastDataTxTick = 0 so first @TL fires immediately     */
            s_lastDataTxTick = 0;
            s_lastAnyTxTick  = HAL_GetTick();
            s_justConnected  = true;
            set_state(LORA_STATE_CONNECTED);
            s_consecCycleFails = 0;
            return LORA_TX_OK;
        }

        /* Handshake failed → retry in 1 s (not 3 s)                  */
        UART_PrintLn("[LORA TX] HELLO failed — retry in 1 s");
        set_state(LORA_STATE_DISCONNECTED);
        schedule_fast_retry();
        return LORA_TX_RETRY;
    }

    /* ── HANDSHAKING (brief transient, entered by TriggerHandshake) ── */
    if (s_state == LORA_STATE_HANDSHAKING)
    {
        if (do_handshake_once())
        {
            s_lastDataTxTick = 0;
            s_lastAnyTxTick  = HAL_GetTick();
            s_justConnected  = true;
            set_state(LORA_STATE_CONNECTED);
            s_consecCycleFails = 0;
            return LORA_TX_OK;
        }
        set_state(LORA_STATE_DISCONNECTED);
        schedule_fast_retry();
        return LORA_TX_RETRY;
    }

    /* ── CONNECTED ───────────────────────────────────────────────────── */

    /* s_justConnected: send @TL immediately on first service call
     * after connecting, regardless of the 10-second data timer.
     * This means s_wirelessDataValid on the RX goes true within
     * seconds of handshake, not after a 10-second hold.              */
    bool data_due = s_justConnected
                    || ((now - s_lastDataTxTick) >= TX_DATA_INTERVAL_MS);

    bool keepalive_due = (!data_due)
                         && ((now - s_lastAnyTxTick) >= TX_KEEPALIVE_INTERVAL_MS);

    if (!data_due && !keepalive_due)
    {
        return LORA_TX_SKIPPED;
    }

    LoRa_TxResult result;

    if (data_due)
    {
        if (s_justConnected)
            UART_PrintLn("[LORA TX] First @TL after connect — sending immediately");

        s_justConnected = false;
        result = send_data_with_retries(tank_level, well_dry);
    }
    else
    {
        result = send_ping() ? LORA_TX_OK : LORA_TX_RETRY;
    }

    /* ── Failure tracking → DISCONNECTED ───────────────────────────── */
    if (result == LORA_TX_OK)
    {
        s_consecCycleFails = 0;
    }
    else
    {
        s_consecCycleFails++;
        char dbg[80];
        snprintf(dbg, sizeof(dbg),
                 "[LORA TX] No-ACK streak: %u/%u",
                 (unsigned)s_consecCycleFails,
                 (unsigned)TX_NOACK_DISCONNECT_THRESH);
        UART_PrintLn(dbg);

        if (s_consecCycleFails >= TX_NOACK_DISCONNECT_THRESH)
        {
            UART_PrintLn("[LORA TX] !!! DISCONNECTED — will re-handshake");
            set_state(LORA_STATE_DISCONNECTED);
            /* Fire first re-HELLO immediately                         */
            s_lastHelloTick = HAL_GetTick() - TX_HELLO_RETRY_INTERVAL_MS;
        }
    }

    return result;
}

/* ── LoRa_Task() inline stub — defined in lora.h ───────────────────── *
 * main.c should call LoRa_Service(level, wd) directly.
 * ──────────────────────────────────────────────────────────────────── */

/* ====================================================================
 * lora.h  —  TRANSMITTER public interface (state-machine version)
 * ==================================================================== */

#ifndef LORA_TX_H
#define LORA_TX_H

#include "stm32f1xx_hal.h"
#include "lora_protocol.h"

/* ── Pin definitions ─────────────────────────────────────────────────── */
#define LORA_NSS_PORT       GPIOA
#define LORA_NSS_PIN        GPIO_PIN_4
#define LORA_RESET_PORT     GPIOA
#define LORA_RESET_PIN      GPIO_PIN_3
#define LORA_DIO0_PORT      GPIOB
#define LORA_DIO0_PIN       GPIO_PIN_1

/* ── TX result ───────────────────────────────────────────────────────── */
typedef enum
{
    LORA_TX_OK = 0,
    LORA_TX_RETRY,
    LORA_TX_FAIL,
    LORA_TX_SKIPPED   /* state machine decided nothing needed this tick */
} LoRa_TxResult;

#define LORA_MODE_TRANSMITTER  0
#define LORA_MODE_RECEIVER     1

/* TX_PACKET_SIZE kept for any code that still uses the legacy buffer   */
#define TX_PACKET_SIZE   MAX_PACKET_LEN

/* ── Debug variable for Live Expressions ─────────────────────────────── */
extern volatile char g_lastTxPacket[MAX_PACKET_LEN];  /* last packet sent OTA */

/* ── Public globals ─────────────────────────────────────────────────── */
extern uint8_t  loraMode;
extern uint8_t  g_txConnected;     /* 1 = CONNECTED, 0 = any other state */
extern uint8_t  g_txDebugMode;
extern uint32_t g_lora_tx_ok;
extern uint32_t g_lora_tx_retry;
extern uint32_t g_lora_tx_fail;

/* ── Primary API ─────────────────────────────────────────────────────── */
void              LoRa_Init           (void);
LoRa_ConnState_t  LoRa_GetState       (void);
const char *      LoRa_GetStateString (void);
uint32_t          LoRa_GetTxSequence  (void);

/* Call once per main-loop tick (200 ms recommended).
 * Passes current ADC values; state machine decides what to transmit.
 * Returns LORA_TX_SKIPPED on most ticks (nothing to send yet).         */
LoRa_TxResult LoRa_Service(uint8_t tank_level, uint8_t well_dry);

/* Force an immediate HELLO (e.g. button press)                         */
bool         LoRa_TriggerHandshake (void);
void         LoRa_ManualHello      (void);   /* alias for above */
void         LoRa_SendBye          (void);

/* Build a data packet into caller buffer (backward compat for adc.c)   */
void LoRa_BuildDataPacket(char *out, uint16_t out_size,
                          uint8_t tank_level, uint8_t well_dry);

/* Low-level register access (kept for compat)                          */
void    LoRa_WriteReg(uint8_t addr, uint8_t data);
uint8_t LoRa_ReadReg (uint8_t addr);

/* ── LoRa_Task() backward compat stub ───────────────────────────────── *
 * Defined inline here so any translation unit that still calls
 * LoRa_Task() will compile and get correct state-machine behaviour.
 * New code should call LoRa_Service(level, wd) directly.
 * ──────────────────────────────────────────────────────────────────── */
static inline LoRa_TxResult LoRa_Task(void)
{
    /* Callers that still use this shim get a keep-alive-only cycle.
     * Switch to LoRa_Service(level, wd) to pass real sensor data.      */
    return LoRa_Service(0, 0);
}

#endif /* LORA_TX_H */
